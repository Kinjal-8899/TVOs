//
//  FirstDemoTVOSApp.swift
//  FirstDemoTVOS
//
//  Created by Harindra Pittalia on 14/07/22.
//

import SwiftUI

@main
struct FirstDemoTVOSApp: App {
    

    
    var body: some Scene {
        WindowGroup {
        
            if  UserDefaultHelper.isUserLoggedIn {
                HomeView()
            } else {
                LoginView()
            }
                   
        }
    }
}
