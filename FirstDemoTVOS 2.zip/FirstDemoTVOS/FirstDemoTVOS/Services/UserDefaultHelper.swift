//
//  UserDefaultHelper.swift
//  FirstDemoTVOS
//
//  Created by Harindra Pittalia on 20/07/22.
//

import Foundation


enum Defaults: String {
    case isUserLoggedIn = "isUserLoggedIn"
}

class UserDefaultHelper: ObservableObject {
    
   static var isUserLoggedIn : Bool {
        get {
            return _get(valueForKey: .isUserLoggedIn) as? Bool ?? false
        }
        set {
            _set(value: newValue, key: .isUserLoggedIn)
        }
    }


    private static func _set(value: Any?, key: Defaults) {
        UserDefaults.standard.set(value, forKey: key.rawValue)
    }

    private static func _get(valueForKey key: Defaults)-> Any? {
        return UserDefaults.standard.value(forKey: key.rawValue)
    }
}
