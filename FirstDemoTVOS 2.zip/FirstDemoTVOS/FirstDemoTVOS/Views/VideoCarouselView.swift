//
//  VideoCarouselView.swift
//  FirstDemoTVOS
//
//  Created by Harindra Pittalia on 19/07/22.
//

import SwiftUI

struct VideoCarouselView: View {
    
    let arrImage = ["bg1","bg2","bg3","bg4"]
    let carouselImage = ["h1","h2","h3"]
    var body: some View {
        NavigationView {
        ScrollView(.vertical) {
                  if !carouselImage.isEmpty {
                    TabView {
                        ForEach(carouselImage, id: \.self) { image in
                            NavigationLink {
                                VideoView()
                            } label: {
                                QuoteCarouselView(image: image)
                                  .focusable()
                                  .frame(width: UIScreen.main.bounds.width * 0.9, height: UIScreen.main.bounds.height * 0.6)
                            }
                        }
                    }
                    .tabViewStyle(.page)
                    .frame(width: UIScreen.main.bounds.width * 0.9, height: UIScreen.main.bounds.height * 0.6)
            }
        
        ScrollView(.horizontal) {
                LazyHStack {
                    ForEach(0..<arrImage.count, id: \.self) { index in
                        NavigationLink {
                            VideoView()
                        } label: {
                            VideoCardView(image: arrImage[index], imageNo: index)
                                .frame(width: 420, height: 420)
                        }
                        .buttonStyle(.card)
                    }
                    .padding(.horizontal, 20)
                    .padding(.vertical, 32)
                }
            }.padding(.horizontal, 60)
        }
    }
    }
}

struct VideoCarouselView_Previews: PreviewProvider {
    static var previews: some View {
        VideoCarouselView()
    }
}

struct QuoteCarouselView: View {
    var image: String
    
    var body: some View {
        Image(image)
            .resizable()
            .aspectRatio(contentMode: .fill)
    }
}
