//
//  NewsView.swift
//  FirstDemoTVOS
//
//  Created by Harindra Pittalia on 18/07/22.
//

import SwiftUI

struct NewsView: View {
    var body: some View {
        
        ScrollView {
           
            LazyVStack(alignment: .leading, spacing: 48) {
                ForEach(0..<5) { _ in
                    NewsCarouselView()
                }
            
            }
        }
        
    }
}

struct NewsView_Previews: PreviewProvider {
    static var previews: some View {
        NewsView()
    }
}
