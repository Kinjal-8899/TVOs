//
//  HomeView.swift
//  FirstDemoTVOS
//
//  Created by Harindra Pittalia on 14/07/22.
//

import SwiftUI

struct HomeView: View {
    
    @State private var showingAlert = false
   
    
    var body: some View {
        NavigationView {
            TabView {
//                NewsView()
//                    .edgesIgnoringSafeArea(.horizontal)
//                    .tag("news")
//                    .tabItem {
//                        Label("News", systemImage: "newspaper")
//                    }
//                SavedView()
//                    .edgesIgnoringSafeArea(.horizontal)
//                    .tag("saved")
//                    .tabItem {
//                        Label("Saved", systemImage: "bookmark")
//                    }
                
                ApiNewsView()
                    .edgesIgnoringSafeArea(.horizontal)
                    .tag("api")
                    .tabItem {
                        Label("API News", systemImage: "newspaper.fill")
                            .font(.custom("Helvetica", size: 22))
                            
                    }
                
                
                VideoCarouselView()
                    .edgesIgnoringSafeArea(.horizontal)
                    .tag("video")
                    .tabItem {
                        Label("Video", systemImage: "video")
                            .font(.custom("Helvetica", size: 22))
                            
                    }
                SearchView()
                    .edgesIgnoringSafeArea(.horizontal)
                    .tag("search")
                    .tabItem {
                        Image(systemName: "magnifyingglass")
    
                    }
            }
            .navigationTitle("")
//            .toolbar(content: {
//                ToolbarItem(placement: .navigationBarLeading) {
//                    Button(action: {
//                        showingAlert = true
//                    }
//                    ){
//                        Image(systemName: "person")
//                    }.frame(width: 50, height: 50)
//                        .alert("Do you want to logout?", isPresented: $showingAlert) {
//                            Button("Yes", role: .destructive) {
//                                logoutUser()
//                            }
//                            Button("No", role: .cancel) {}
//                        }
//
//                }
//
//            })
            
        }
    }
    
    private func logoutUser() {
        UserDefaultHelper.isUserLoggedIn = false
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
