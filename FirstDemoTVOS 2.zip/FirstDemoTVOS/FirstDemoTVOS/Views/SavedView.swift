//
//  SearchView.swift
//  FirstDemoTVOS
//
//  Created by Harindra Pittalia on 18/07/22.
//

import SwiftUI

struct SavedView: View {
    var body: some View {
        HStack {
            Spacer()
            gridView
            Spacer()
        }
    }
    
    private var gridItems: [GridItem] {
        [GridItem(.adaptive(minimum: 400),spacing: 32)]
    }
    
    private var gridView: some View {
       
        ScrollView {
            LazyVGrid(columns: gridItems, spacing: 48) {
                ForEach(Range(0...5)) {_ in
                    NavigationLink {
                        NewsDetailView()
                    } label: {
                        ItemView()
                            .frame(width: 400, height: 400)
                    }
                    .buttonStyle(.card)
                    .contextMenu {
                        Button {
                            print("Bookmark added")
                        } label: {
                            Text("Bookmark")
                        }
                    }
                }
            }
            .padding(.horizontal, 20)
            .padding(.top, 32)
        
        }
        
    }
}

struct SavedView_Previews: PreviewProvider {
    static var previews: some View {
        SavedView()
    }
}
