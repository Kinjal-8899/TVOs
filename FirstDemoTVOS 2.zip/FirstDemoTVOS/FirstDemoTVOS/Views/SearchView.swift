//
//  SearchView.swift
//  FirstDemoTVOS
//
//  Created by Harindra Pittalia on 18/07/22.
//

import SwiftUI

struct SearchView: View {
    
    @State private var searchText: String = ""
    @StateObject var newsViewModel : NewsViewModel = NewsViewModel()
    
    var body: some View {
        NavigationView {
            VideoGridView(articles: newsViewModel.articles.filter({
                searchText.isEmpty ? true : $0.title?.contains(searchText) as! Bool
            }))
               
        }
        .searchable(text: $searchText)
        .onChange(of: searchText) { searchText in
            //filter articles
    
        }.onAppear {
            self.newsViewModel.getNewsList()
        }
    }
}

struct SearchView_Previews: PreviewProvider {
    static var previews: some View {
      
        SearchView()
        
    }
}
