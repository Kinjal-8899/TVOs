//
//  ItemView.swift
//  FirstDemoTVOS
//
//  Created by Harindra Pittalia on 15/07/22.
//

import SwiftUI

struct ItemView: View {
    
    
    var body: some View {
        GeometryReader { proxy in
            VStack(alignment: .leading, spacing: 24) {
                Image("user-1")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(height: proxy.size.height * 0.6)
                    .background(Color.gray.opacity(0.6))
                    .clipped()
                VStack(alignment: .leading) {
                    Text("The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.")
                        .font(.subheadline)
                        .foregroundStyle(.primary)
                        .lineLimit(3)
                    Spacer(minLength: 12)
                    HStack {
                        
                        Text("RT")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                        Spacer()
                        Image(systemName: "bookmark")
                        
                    }
                }
                .padding([.horizontal,.bottom])
            }
        }
    }
    
}

struct ItemView_Previews: PreviewProvider {
    static var previews: some View {
        ItemView()
    }
}
