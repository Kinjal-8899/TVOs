//
//  ApiItemView.swift
//  FirstDemoTVOS
//
//  Created by Harindra Pittalia on 19/07/22.
//

import SwiftUI

struct ApiItemView: View {
    let article: Article
    
    var body: some View {
        GeometryReader { proxy in
            VStack(alignment: .leading, spacing: 24) {
                asyncImage
                    .frame(height: proxy.size.height * 0.6)
                    .aspectRatio(contentMode: .fill)
                    .background(Color.gray.opacity(0.6))
                    .clipped()
                VStack(alignment: .leading) {
                    Text(article.title ?? "")
                        .font(.custom("Helvetica", size: 22))
                        .bold()
                        .foregroundStyle(.primary)
                        .lineLimit(3)
                    Spacer(minLength: 12)
                    HStack {
                        
                        Text("RT")
                            .font(.custom("Helvetica", size: 18))
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                        Spacer()
                        Image(systemName: "bookmark")
                        
                    }
                }
                .padding([.horizontal,.bottom])
            }
            
        }
    }
    
    private var asyncImage: some View  {
        AsyncImage(url: URL(string: article.urlToImage ?? "")) { phase in
            switch phase {
            case .empty:
                HStack {
                    Spacer()
                    ProgressView()
                    Spacer()
                }
                
            case .success(let image):
                image
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                
            case .failure:
                HStack {
                    Spacer()
                    Image(systemName: "photo")
                        .imageScale(.large)
                    Spacer()
                }
                
                
            @unknown default:
                fatalError()
            }
        }
    }
}

struct ApiItemView_Previews: PreviewProvider {
    static var previews: some View {
        ApiItemView(article: Article(source: Source(id: "", name: ""), author: "", title: "", articleDescription: "", url: "", urlToImage: "", publishedAt: "", content: ""))
    }
}
