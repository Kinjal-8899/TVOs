//
//  ApiNewsView.swift
//  FirstDemoTVOS
//
//  Created by Harindra Pittalia on 19/07/22.
//

import SwiftUI

struct ApiNewsView: View {
    
    @StateObject var newsViewModel : NewsViewModel = NewsViewModel()
    
    var body: some View {
       
        ApiNewsCarouselView(articles: newsViewModel.articles)
          
        .onAppear {
            self.newsViewModel.getNewsList()
        }
        
    }
        
}

struct ApiNewsView_Previews: PreviewProvider {
    static var previews: some View {
        ApiNewsView()
    }
}
