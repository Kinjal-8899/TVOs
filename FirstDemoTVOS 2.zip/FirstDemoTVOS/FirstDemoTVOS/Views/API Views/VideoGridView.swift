//
//  VideoGridView.swift
//  FirstDemoTVOS
//
//  Created by Harindra Pittalia on 21/07/22.
//

import SwiftUI

struct VideoGridView: View {
    
    var articles: [Article]
    
    var body: some View {
        HStack {
            Spacer()
            gridView
            Spacer()
                
        }
    }
    
    private var gridItems: [GridItem] {
        [GridItem(.adaptive(minimum: 350),spacing: 32)]
    }
    
    private var gridView: some View {
       
        ScrollView {
            LazyVGrid(columns: gridItems, spacing: 42) {
                ForEach(articles) {article in
                    NavigationLink {
                        ApiDetailView(article: article)
                    } label: {
                        ApiItemView(article: article)
                            .frame(width: 350, height: 350)
                    }
                    .buttonStyle(.card)
                    .contextMenu {
                        Button {
                            print("Bookmark added")
                        } label: {
                            Text("Bookmark")
                        }
                    }
                }
            }
            .padding(.horizontal, 20)
            .padding(.top, 32)
        
        }
        
    }
}

struct VideoGridView_Previews: PreviewProvider {
    static var previews: some View {
        VideoGridView(articles: [Article]())
    }
}
