//
//  ApiNewsCarouselView.swift
//  FirstDemoTVOS
//
//  Created by Harindra Pittalia on 19/07/22.
//

import SwiftUI

struct ApiNewsCarouselView: View {
    
    let articles : [Article]
    
    
    var body: some View {
       // NavigationView {
        VStack(alignment: .leading) {
            
            Text("This News Are From News API")
                .font(.custom("Helvetica", size: 30))
                .bold()
                .foregroundColor(.primary)
                .padding(.horizontal,64)
            
            
                ScrollView(.horizontal) {
                    LazyHStack(spacing: 32) {
                        ForEach(articles) { article in
                            NavigationLink {
                                ApiDetailView(article: article)
                            } label: {
                                ApiItemView(article: article)
                                    .frame(width: 420, height: 420)
                            }
                            .buttonStyle(.card)
                            .contextMenu {
                                Button {
                                    print("Bookmark added")
                                } label: {
                                    Text("Bookmark")
                                }
                            }
                        }
                    }
                    .padding([.bottom,.horizontal], 64)
                    .padding(.top, 32)
                }
        //    }
            
        }
        
    }

}

struct ApiNewsCarouselView_Previews: PreviewProvider {
    static var previews: some View {
        ApiNewsCarouselView(articles: [Article]())
    }
}
