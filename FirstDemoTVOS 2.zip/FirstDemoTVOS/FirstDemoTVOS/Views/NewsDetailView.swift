//
//  NewsDetailView.swift
//  FirstDemoTVOS
//
//  Created by Harindra Pittalia on 18/07/22.
//

import SwiftUI

struct NewsDetailView: View {
    var body: some View {
        VStack(alignment: .leading) {
            Text("Lorem Ipsum is simply dummy text of the printing and typesetting industry.")
                .font(.title)
                .foregroundStyle(.primary)
                .padding(.bottom)
            Text("Contrary to popular belief, Lorem Ipsum is not simply random text.")
                .font(.subheadline)
                .padding(.bottom)
            detailView
        }
    }
    
    private var detailView: some View {
        HStack(alignment: .top) {
            newsImage
            Spacer()
            ScrollView {
                VStack(alignment: .leading, spacing: 32) {
                    Text("It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).")
                        .font(.headline)
                    Text("There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.")
                        .foregroundStyle(.secondary)
                    Button {
                        print("Add Bookmark pressed")
                    } label: {
                        Text("Add Bookmark")
                    }

                }
            }
        }
    }
    
    private var newsImage: some View {
        Image("user-1")
            .resizable()
            .aspectRatio(contentMode: .fill)
            .frame(minWidth: 400, maxWidth: 400, maxHeight: 648)
            .background(Color.gray.opacity(0.6))
            .clipped()
            .cornerRadius(16)
    }
    
}

struct NewsDetailView_Previews: PreviewProvider {
    static var previews: some View {
        NewsDetailView()
    }
}
