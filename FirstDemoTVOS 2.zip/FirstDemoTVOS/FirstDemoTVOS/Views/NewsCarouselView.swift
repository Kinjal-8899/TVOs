//
//  NewsCarouselView.swift
//  FirstDemoTVOS
//
//  Created by Harindra Pittalia on 18/07/22.
//

import SwiftUI

struct NewsCarouselView: View {
    
    var body: some View {
        VStack(alignment: .leading) {
            Text("Latest News")
                .foregroundColor(.primary)
                .font(.headline)
                .padding(.horizontal,64)
            
            ScrollView(.horizontal) {
                LazyHStack(spacing: 32) {
                    ForEach(Range(0...5)) { _ in
                        NavigationLink {
                            NewsDetailView()
                        } label: {
                            ItemView()
                                .frame(width: 420, height: 420)
                        }
                        .buttonStyle(.card)
                        .contextMenu {
                            Button {
                                print("Bookmark added")
                            } label: {
                                Text("Bookmark")
                            }
                        }
                    }
                }
                .padding([.bottom,.horizontal], 64)
                .padding(.top, 32)
            }
        }
    }
        
}

struct NewsCarouselView_Previews: PreviewProvider {
    static var previews: some View {
        NewsCarouselView()
    }
}
