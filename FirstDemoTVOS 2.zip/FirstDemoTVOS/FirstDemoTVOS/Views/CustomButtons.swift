//
//  CustomButtons.swift
//  FirstDemoTVOS
//
//  Created by Harindra Pittalia on 14/07/22.
//

import Foundation
import SwiftUI

struct RoundedButtonStyle: ButtonStyle {
    func makeBody(configuration: Self.Configuration) -> some View {
        RoundedButton(configuration: configuration)
    }
}

struct RoundedButton: View {
    @Environment(\.isFocused) var focused: Bool
    let configuration: ButtonStyle.Configuration
    
    var body: some View {
        configuration.label
            .padding()
            .background(Color(.red))
            .foregroundColor(.white)
            .clipShape(Capsule())
            .scaleEffect(focused ? 1.1 : 1)
            .focusable(true)
    }
}

struct PlainButtonStyle: ButtonStyle {
    func makeBody(configuration: Self.Configuration) -> some View {
        PlainButton(configuration: configuration)
    }
}

struct PlainButton: View {
    @Environment(\.isFocused) var focused: Bool
    let configuration: ButtonStyle.Configuration
    
    var body: some View {
        configuration.label
            .scaleEffect(focused ? 1.1 : 1)
            .focusable(true)
            .foregroundColor(focused ? .white : .gray)
    }
}
