//
//  VideoView.swift
//  FirstDemoTVOS
//
//  Created by Harindra Pittalia on 19/07/22.
//

import SwiftUI
import AVKit

struct VideoView: View {
    
    @State private var player: AVQueuePlayer?
    @State private var videoLooper: AVPlayerLooper?
    let videoURLs = ["http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
                     "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackOnStreetAndDirt.mp4",
                     "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4"]
    
    
    var body: some View {
        VideoPlayer(player: player)
          .onAppear {
            if player == nil {
              // swiftlint:disable:next force_unwrapping
                let templateItem = AVPlayerItem(url: URL(string: videoURLs.randomElement() ?? "")!)
              player = AVQueuePlayer(playerItem: templateItem)
              // swiftlint:disable:next force_unwrapping
              videoLooper = AVPlayerLooper(player: player!, templateItem: templateItem)
                player?.play()
            }

           
          }
          .edgesIgnoringSafeArea(.all)
        
    }
}

struct VideoView_Previews: PreviewProvider {
    static var previews: some View {
        VideoView()
    }
}
