//
//  ContentView.swift
//  FirstDemoTVOS
//
//  Created by Harindra Pittalia on 14/07/22.
//

import SwiftUI

struct LoginView: View {
    
    @ObservedObject var loginViewModel = LoginViewModel()
    
    
    var body: some View {
        
        VStack {
            Spacer()
            Text("Welcome User")
                .font(.largeTitle)
                .bold()
                .foregroundColor(.red)
            Spacer()
            HStack {
                Spacer()
                Image("people")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 500, height: 500, alignment: .center)
                Spacer()
                VStack {
                    VStack(alignment: .leading, spacing: 5) {
                        Text("Username")
                        TextField("Username", text: $loginViewModel.loginDataModel.userEmail)
                            .keyboardType(.emailAddress)
                        
                    }
                    VStack(alignment: .leading, spacing: 5) {
                        Text("Password")
                        SecureField("Password", text: $loginViewModel.loginDataModel.userPassword)
                    }
                    
        
                    Button {
                        loginViewModel.loginUser()
                    } label: {
                        HStack {
                            Spacer()
                            Text("Sign In")
                            Spacer()
                        }
                    }.buttonStyle(RoundedButtonStyle())
                    
                    Button("Forgot Password?") {
                        
                    }.buttonStyle(PlainButtonStyle())
                    
                }.frame(width: 500, alignment: .center)
                
                Spacer()
            }
            
            Spacer()
               
        }
        .alert(loginViewModel.loginDataModel.errorMessage, isPresented: $loginViewModel.loginDataModel.isPresentingErrorAlert) {
                    Button("OK", role: .cancel) { }
        }
        .sheet(isPresented: $loginViewModel.loginDataModel.navigate, content: {
            
                HomeView()
            
        })
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView()
    }
}

