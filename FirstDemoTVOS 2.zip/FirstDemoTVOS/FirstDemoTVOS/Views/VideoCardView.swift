//
//  VideoCardView.swift
//  FirstDemoTVOS
//
//  Created by Harindra Pittalia on 20/07/22.
//

import SwiftUI

struct VideoCardView: View {
    
    var image: String
    var imageNo: Int
    @Environment(\.isFocused) var focused: Bool
    
    var body: some View {
        GeometryReader { proxy in
            VStack{
                Image(image)
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: proxy.size.width,height: proxy.size.height * 0.9)
                    .background(Color.gray.opacity(0.6))
                    .clipped()
                    
             Text("Video \(imageNo + 1)")
                    .font(.custom("Helvetica", size: 22))
                    .bold()
                    .foregroundStyle(.primary)
            }
//            .overlay( focused ?
//                       RoundedRectangle(cornerRadius: 16)
//                               .stroke(.blue, lineWidth: 20) :
//                               RoundedRectangle(cornerRadius: 16)
//                                       .stroke(.white, lineWidth: 0)
//                   )
        }
    }
}

struct VideoCardView_Previews: PreviewProvider {
    static var previews: some View {
        VideoCardView(image: "bg1", imageNo: 1)
    }
}
