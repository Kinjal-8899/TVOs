//
//  LoginViewModel.swift
//  FirstDemoTVOS
//
//  Created by Harindra Pittalia on 19/07/22.
//

import Foundation

struct LoginDataModel {
    var userEmail: String = "kinjal.panchal@bacancy.com"
        var userPassword: String = "123456"
        var errorMessage: String = String()
        var navigate: Bool = false
        var isPresentingErrorAlert: Bool = false
}

//MARK: - LoginViewModel
class LoginViewModel: ObservableObject
{
    

    @Published var loginDataModel = LoginDataModel()
    private let loginResource: LoginResource = LoginResource()

    func loginUser()
    {
        if loginDataModel.userEmail.isEmpty {
            loginDataModel.errorMessage = "Please enter Username"
            loginDataModel.isPresentingErrorAlert = true
        } else if loginDataModel.userPassword.isEmpty {
            loginDataModel.errorMessage = "Please enter Password"
            loginDataModel.isPresentingErrorAlert = true
        }
        else {
            loginResource.loginUser(email: loginDataModel.userEmail, password: loginDataModel.userPassword) { result in
                DispatchQueue.main.async {
                    if result?.data != nil {
                        UserDefaultHelper.isUserLoggedIn = true
                        self.loginDataModel.navigate = true
                    } else {
                        self.loginDataModel.errorMessage = result?.message ?? "error occured"
                        self.loginDataModel.isPresentingErrorAlert = true
                    }
                }
            }
        }
    }
}

