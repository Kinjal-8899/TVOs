//
//  NewsViewModel.swift
//  FirstDemoTVOS
//
//  Created by Harindra Pittalia on 18/07/22.
//

import Foundation

class NewsViewModel: ObservableObject {
    
    let newsResource : NewsResource!
    @Published var articles: [Article] = [Article]()
    @Published var gotResponse: Bool = false
    
    init() {
        self.newsResource = NewsResource()
    }
    
    func getNewsList()  {
        self.gotResponse = false
        newsResource.getNewsList { result in
            DispatchQueue.main.async {
                if result.status == "ok" {
                    print(result.articles)
                    self.gotResponse = true
                    self.articles = result.articles ?? [Article]()
                }
            }
        }
    }
}
