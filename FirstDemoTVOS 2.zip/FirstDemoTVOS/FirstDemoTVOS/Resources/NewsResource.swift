//
//  NewsResource.swift
//  FirstDemoTVOS
//
//  Created by Harindra Pittalia on 18/07/22.
//

import Foundation


struct NewsResource {
    
    //MARK: - get Job List
    func getNewsList(completion: @escaping (_ result: ArticleModel) -> Void) {
        CommonWS.GetURLWithoutParameter(url: "APIUrls.getJobs") { responseData, success in
            if success {
                do {
                    let jsonData = try JSONSerialization.data(withJSONObject: responseData, options: .prettyPrinted)
                    let reqJSONStr = String(data: jsonData, encoding: .utf8)
                    let data = reqJSONStr?.data(using: .utf8)
                    let news = try JSONDecoder().decode(ArticleModel.self, from: data!)
                    //print(news)
                    completion(news)
                } catch  {
                    print(error.localizedDescription)
                }
            } else {
                completion(ArticleModel(status: nil, totalResults: nil, articles: nil))
            }
        }
    }
    
}
