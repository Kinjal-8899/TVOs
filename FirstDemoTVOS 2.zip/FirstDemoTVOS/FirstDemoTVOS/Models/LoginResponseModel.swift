//
//  LoginResponseModel.swift
//  FirstDemoTVOS
//
//  Created by Harindra Pittalia on 19/07/22.
//

import Foundation

//MARK: - LoginResponse
struct LoginResponse : Decodable {
    let data: LoginResponseData?
    let type: String?
    let status: Int?
    let message: String?
}

//MARK: - LoginResponseData
struct LoginResponseData : Decodable
{
    let id, companyID: Int?
    let companyName, fullname, email: String?
    let hourlyRate: Int?
    let mobile, profilePic: String?
    let notification, location, bluetooth: Bool?
    let authToken: String?
    
    enum CodingKeys: String, CodingKey {
        case id
        case companyID = "company_id"
        case companyName = "company_name"
        case fullname, email
        case hourlyRate = "hourly_rate"
        case mobile
        case profilePic = "profile_pic"
        case notification, location, bluetooth
        case authToken = "auth_token"
    }
}
